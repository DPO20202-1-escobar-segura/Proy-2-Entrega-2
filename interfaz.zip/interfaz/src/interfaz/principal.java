package interfaz;

public class principal {
	public static void main(String [] args) {
		main1 v1 =  new main1();
		
		v1.setVisible(true);
		
	}

}
