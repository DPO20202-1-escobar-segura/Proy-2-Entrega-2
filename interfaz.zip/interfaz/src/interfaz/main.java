package interfaz;

public interface main {
	
	public void ingresarusuario() {
		
	}
	
	public void agregarusuario() {
		
	}
	
	public void cerrarmenu() {
		
	}


}
