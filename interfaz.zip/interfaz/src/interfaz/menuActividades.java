package interfaz;
import java.awt.Color;

import javax.swing.*;
public class menuActividades extends JFrame{
	public menuActividades() {
		public nuevaActividad() {
			this.setSize(1000 , 1000);
			setTitle("proyecto: escobar-segura");
			setLocationRelativeTo(null);
			setDefaultCloseOperation(EXIT_ON_CLOSE);
			
			componentes();
		
	}
		private void componentes() {
			JPanel panel1 = new JPanel();
			panel1.setBackground(Color.BLUE);
			panel1.setLayout(null);
			this.getContentPane().add(panel1);
			
			JLabel etiqueta = new JLabel();
			etiqueta.setText("actividades registradas:");
			etiqueta.setHorizontalAlignment(SwingConstants.CENTER);
			etiqueta.setForeground(Color.WHITE);
			etiqueta.setFont(new Font("arial", Font.PLAIN,15));
			panel1.add(etiqueta);
			
			JButton boton1 = new JButton();
			boton1.setText("regresar");
			boton1.setEnabled(true);
			boton1.setBounds(10, 1000, 100, 50);
			boton1.setFont(new Font("arial", Font.PLAIN ,25));
			panel1.add(boton1);
			
			JButton boton2 = new JButton();
			boton2.setText("crear nueva actividad");
			boton2.setEnabled(true);
			boton2.setBounds(950, 1000, 100, 50);
			boton2.setFont(new Font("arial", Font.PLAIN ,25));
			panel1.add(boton2);
			
			JButton boton3 = new JButton();
			boton3.setText("generar reporte");
			boton3.setEnabled(true);
			boton3.setBounds(450, 1000, 100, 50);
			boton3.setFont(new Font("arial", Font.PLAIN ,25));
			panel1.add(boton2);
			

}
