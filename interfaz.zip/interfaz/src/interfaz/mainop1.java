package interfaz;
import java.awt.Color;

import javax.swing.*;

public class mainop1 extends JFrame {
	
	public mainop1() {
		this.setSize(500 , 500);
		setTitle("proyecto: escobar-segura");
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		componentes();
		
	}
	
	
	private void componentes() {
		JPanel panel1 = new JPanel();
		panel1.setBackground(Color.BLUE);
		panel1.setLayout(null);
		this.getContentPane().add(panel1);
		
		
		JLabel etiqueta = new JLabel();
		etiqueta.setText("complete con sus datos");
		etiqueta.setHorizontalAlignment(SwingConstants.CENTER);
		etiqueta.setForeground(Color.WHITE);
		etiqueta.setFont(new Font("arial", Font.PLAIN,15));
		panel1.add(etiqueta);
		
		
		JLabel etiqueta1 = new JLabel();
		etiqueta1.setText("ingrese nombre");
		etiqueta1.setHorizontalAlignment(SwingConstants.CENTER);
		etiqueta1.setForeground(Color.WHITE);
		etiqueta1.setFont(new Font("arial", Font.PLAIN,15));
		etiqueta1.setBounds(100,100,50,30);
		panel1.add(etiqueta1);
		
		
		JTextField cajatexto1 = new JTextField();
		cajatexto1.setBounds(100,200,100,30);
		System.out.println("nombre:" + cajatexto1.getText());
		panel1.add(cajatexto1);

		
		JLabel etiqueta2 = new JLabel();
		etiqueta2.setText("ingrese correo");
		etiqueta2.setHorizontalAlignment(SwingConstants.CENTER);
		etiqueta2.setForeground(Color.WHITE);
		etiqueta2.setFont(new Font("arial", Font.PLAIN,15));
		etiqueta2.setBounds(100,350,50,30);
		panel1.add(etiqueta2);
		
		
		JTextField cajatexto2 = new JTextField();
		cajatexto2.setBounds(100,450,100,30);
		System.out.println("correo:" + cajatexto2.getText());
		panel1.add(cajatexto2);
		
		
		
		JButton boton1 = new JButton();
		boton1.setText("regresar");
		boton1.setEnabled(true);
		boton1.setBounds(10, 500, 100, 50);
		boton1.setFont(new Font("arial", Font.PLAIN ,25));
		panel1.add(boton1);
		
		JButton boton2 = new JButton();
		boton2.setText("aceptar");
		boton2.setEnabled(true);
		boton2.setBounds(450, 500, 100, 50);
		boton2.setFont(new Font("arial", Font.PLAIN ,25));
		panel1.add(boton2);
	
	}


}
