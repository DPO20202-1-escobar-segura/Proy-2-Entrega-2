package interfaz;
import java.awt.Color;

import javax.swing.*;

public class mainabrirproyecto extends JFrame {
	public mainabrirproyecto() {
		this.setSize(500 , 500);
		setTitle("proyecto: escobar-segura");
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		componentes();
		
	}		
		
		private void componentes() {
			JPanel panel1 = new JPanel();
			panel1.setBackground(Color.BLUE);
			panel1.setLayout(null);
			this.getContentPane().add(panel1);
			
			JLabel etiqueta = new JLabel();
			etiqueta.setText("seleccione una de las opciones");
			etiqueta.setHorizontalAlignment(SwingConstants.CENTER);
			etiqueta.setForeground(Color.WHITE);
			etiqueta.setFont(new Font("arial", Font.PLAIN,15));
			panel1.add(etiqueta);
			
			JButton boton1 = new JButton();
			boton1.setText("nuevo proyecto");
			boton1.setEnabled(true);
			boton1.setBounds(250, 100, 250, 250);
			boton1.setFont(new Font("arial", Font.PLAIN ,75));
			panel1.add(boton1);
			
			JButton boton2 = new JButton();
			boton2.setText("abrir proyecto");
			boton2.setEnabled(true);
			boton2.setBounds(250, 400, 250, 250);
			boton2.setFont(new Font("arial", Font.PLAIN ,75));
			panel1.add(boton2);
		
		
	}

}
