package interfaz;
import java.awt.Color;

import javax.swing.*;

public class maincrearproyecto extends JFrame {
	public maincrearproyecto() {
		this.setSize(1000 , 1000);
		setTitle("proyecto: escobar-segura");
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		componentes();
	}
	
	
		private void componentes() {
			JPanel panel1 = new JPanel();
			panel1.setBackground(Color.BLUE);
			panel1.setLayout(null);
			this.getContentPane().add(panel1);
			
			JLabel etiqueta = new JLabel();
			etiqueta.setText("complete con su informacion");
			etiqueta.setHorizontalAlignment(SwingConstants.CENTER);
			etiqueta.setForeground(Color.WHITE);
			etiqueta.setFont(new Font("arial", Font.PLAIN,15));
			panel1.add(etiqueta);
			
			
			JLabel etiqueta1 = new JLabel();
			etiqueta1.setText("ingrese nombre");
			etiqueta1.setHorizontalAlignment(SwingConstants.CENTER);
			etiqueta1.setForeground(Color.WHITE);
			etiqueta1.setFont(new Font("arial", Font.PLAIN,15));
			etiqueta1.setBounds(100,100,50,30);
			panel1.add(etiqueta1);
			
			
			JTextField cajatexto1 = new JTextField();
			cajatexto1.setBounds(100,200,100,30);
			System.out.println("nombre:" + cajatexto1.getText());
			panel1.add(cajatexto1);
			
			JLabel etiqueta2 = new JLabel();
			etiqueta2.setText("ingrese descripcion");
			etiqueta2.setHorizontalAlignment(SwingConstants.CENTER);
			etiqueta2.setForeground(Color.WHITE);
			etiqueta2.setFont(new Font("arial", Font.PLAIN,15));
			etiqueta2.setBounds(100,350,50,30);
			panel1.add(etiqueta2);
			
			JTextArea areaTexto = new JTextArea();
			areaTexto.setBounds(100, 450, 100 ,100);
			panel1.add(areaTexto);
			
			
			JLabel etiqueta3 = new JLabel();
			etiqueta3.setText("fecha incial");
			etiqueta3.setHorizontalAlignment(SwingConstants.CENTER);
			etiqueta3.setForeground(Color.WHITE);
			etiqueta3.setFont(new Font("arial", Font.PLAIN,15));
			etiqueta3.setBounds(100,650,50,30);
			panel1.add(etiqueta3);
			
			JTextField cajatexto2 = new JTextField();
			cajatexto2.setBounds(100,750,100,30);
			System.out.println("nombre:" + cajatexto2.getText());
			panel1.add(cajatexto2);
			
			
			JLabel etiqueta4 = new JLabel();
			etiqueta4.setText("fecha final");
			etiqueta4.setHorizontalAlignment(SwingConstants.CENTER);
			etiqueta4.setForeground(Color.WHITE);
			etiqueta4.setFont(new Font("arial", Font.PLAIN,15));
			etiqueta4.setBounds(100,850,50,30);
			panel1.add(etiqueta4);
			
			JTextField cajatexto3 = new JTextField();
			cajatexto3.setBounds(100,950,100,30);
			System.out.println("nombre:" + cajatexto3.getText());
			panel1.add(cajatexto3);
			
			
			JButton boton1 = new JButton();
			boton1.setText("regresar");
			boton1.setEnabled(true);
			boton1.setBounds(10, 1000, 100, 50);
			boton1.setFont(new Font("arial", Font.PLAIN ,25));
			panel1.add(boton1);
			
			JButton boton2 = new JButton();
			boton2.setText("aceptar");
			boton2.setEnabled(true);
			boton2.setBounds(950, 1000, 100, 50);
			boton2.setFont(new Font("arial", Font.PLAIN ,25));
			panel1.add(boton2);
			
			
			
			
	}

}
